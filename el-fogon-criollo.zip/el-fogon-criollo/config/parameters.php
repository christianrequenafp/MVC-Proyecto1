<?php
define("default_action", "index");
define("url","http://localhost/MVC-Proyecto1/el-fogon-criollo/")
?>